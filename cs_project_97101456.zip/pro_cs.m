%% pulse
b = randi([0 1], 1, 50);
B = divide(b);
b1 = B{1};
b2 = B{2};
p1 = ones(1,10^4);
zero = zeros(1,10^4);
p0 = zero - p1;
x1 = pulse_shaping(b1, p1, p0);
x2 = pulse_shaping(b2, p1, p0);
%t0 = 1:25*10^4;
%plot(t0,x1);
t = 10^-6:10^-6:25*10^-2;
am = anglemod(10^4, 10^6, x1, x2);
%plot(t(1,1:20000),am(1,1:20000));
ch = channel(10^4, 10^6, am, 1000);
%plot(t,ch);
ade = angledemod(10^4, 10^6, ch, 1000);
%plot(t,ade{1});
mf1 = matchfilter(ade{1}, p0, p1);
mf2 = matchfilter(ade{2}, p0, p1);
%disp(mf1{3});
%disp(b1);
out = combine(mf2{3}, mf1{3});
disp(out);
disp(b);
%% plot error pulse
prob = zeros(1,26);
tav = zeros(1,26);
for i = 0:25
    tav(i+1) = i*4;
    wn = wgn(1, 250000, i*4);
    amp = am + wn;
    ch = channel(10^4, 10^6, amp, 1000);
    ade = angledemod(10^4, 10^6, ch, 1000);
    mf1 = matchfilter(ade{1}, p0, p1);
    mf2 = matchfilter(ade{2}, p0, p1);
    out = combine(mf2{3}, mf1{3});
    e = 0;
    for j = 1:50
        if out(j) ~= b(j) 
            e = e+1;
        end
    end
    prob(i+1) = e * 2;
end
plot(tav,prob);
%% plot scatter pulse
wn = wgn(1, 250000, 80);
amp = am + wn;
ch = channel(10^4, 10^6, amp, 1000);
ade = angledemod(10^4, 10^6, ch, 1000);
mf1 = matchfilter(ade{1}, p0, p1);
mf2 = matchfilter(ade{2}, p0, p1);
scatter([mf1{1} mf1{2}], [mf2{1} mf2{2}]);

%% sin
bs = randi([0 1], 1, 250);
Bs = divide(bs);
bs1 = Bs{1};
bs2 = Bs{2};
ts = 10^-6:10^-6:2*10^-3;
t = 10^-6:10^-6:25*10^-2;
s0 = -1*sin(2*pi*500*ts);
s1 = sin(2*pi*500*ts);
xs1 = pulse_shaping(bs1, s1, s0);
xs2 = pulse_shaping(bs2, s1, s0);
%plot(t0,xs1);
ams = anglemod(10^4, 10^6, xs1, xs2);
%plot(t(1,1:5000),ams(1,1:5000));
chs = channel(10^4, 10^6, ams, 1000);
%plot(t,chs);
ades = angledemod(10^4, 10^6, chs, 1000);
%plot(t,dea{1});
mfs1 = matchfilter(ades{1}, s0, s1);
mfs2 = matchfilter(ades{2}, s0, s1);
%disp(ma1{3});
%disp(b1);
outs = combine(mfs2{3}, mfs1{3});
m_one = ones(1,length(outs));
outs = m_one - outs;
disp(outs(1,1:30));
disp(bs(1,1:30));

%% plot error sin
probs = zeros(1,26);
tavs = zeros(1,26);
for i = 0:25
    tavs(i+1) = i*4;
    wn = wgn(1, 250000, i*4);
    amsp = ams + wn;
    chs = channel(10^4, 10^6, amsp, 1000);
    ades = angledemod(10^4, 10^6, chs, 1000);
    mfs1 = matchfilter(ades{1}, s0, s1);
    mfs2 = matchfilter(ades{2}, s0, s1);
    outs = combine(mfs2{3}, mfs1{3});
    m_one = ones(1,length(outs));
    outs = m_one - outs;
    e = 0;
    for j = 1:250
        if outs(j) ~= bs(j) 
            e = e+1;
        end
    end
    probs(i+1) = e / 2.5;
end
plot(tavs,probs);

%% plot scatter sin
wn = wgn(1, 250000, 80);
amsp = ams + wn;
chs = channel(10^4, 10^6, amsp, 1000);
ades = angledemod(10^4, 10^6, chs, 1000);
mfs1 = matchfilter(ades{1}, s0, s1);
mfs2 = matchfilter(ades{2}, s0, s1);
scatter([mfs1{1} mfs1{2}], [mfs2{1} mfs2{2}]);


%% functions
function out = divide(b)
    m = length(b);
    out = {};
    b1 = zeros(1,m/2);
    b2 = zeros(1,m/2);
    for i = 1:m
        if(mod(i,2) == 0)
            b1(i/2) = b(i);
        else
            b2((i+1)/2) = b(i);
        end
    end
    out{1} = b1;
    out{2} = b2;
end

function out = pulse_shaping(b,p1,p0)
    m = length(b);
    n = length(p1);
    out = zeros(1,m*n);
    for i = 1:m
        if(b(i) == 0)
            out(1,(i-1)*n+1:i*n) = p0(1,:);
        else
            out(1,(i-1)*n+1:i*n) = p1(1,:);
        end
    end
end

function out = anglemod(fcar, fs, x1, x2)
    Ts = 1 / fs;
    k  = (25*10^-2) * fs;
    xc1 = zeros(1,k);
    xc2 = zeros(1,k);
    out = zeros(1,k);
    for i = 1:k
        xc1(i) = x1(i) * cos(2*pi*fcar*i*Ts);
        xc2(i) = x2(i) * sin(2*pi*fcar*i*Ts);
        out(i) = xc1(i) + xc2(i);
    end
end

function out = channel(fc, fs, xc, w)
    out = bandpass(xc, [fc-w/2 fc+w/2], fs);
end

function out = angledemod(fcar, fs, xc, w)
    out = {};
    Ts = 1 / fs;
    k  = (25*10^-2) * fs;
    xc1 = zeros(1,k);
    xc2 = zeros(1,k);
    for i = 1:k
        xc1(i) = xc(i) * cos(2*pi*fcar*i*Ts);
        xc2(i) = xc(i) * sin(2*pi*fcar*i*Ts);
    end
    out{1} = lowpass(xc1, w, fs);
    out{2} = lowpass(xc2, w, fs);
end

function out = matchfilter(x, p0, p1)
    c1 = conv(x,p0);
    c2 = conv(x,p1);
    n = length(p0);
    m = length(x);
    l = m/n;
    out = {};
    out{1} = zeros(1,l);
    out{2} = zeros(1,l);
    out{3} = zeros(1,l);
    for i = 1:l
        out{1}(i) = c1(i*n);
        out{2}(i) = c2(i*n);
        if(out{1}(i) > out{2}(i))
            out{3}(i) = 0;
        else
            out{3}(i) = 1;
        end
    end
end

function out = combine(b1, b2)
    n = length(b1);
    out = zeros(1,2*n);
    for i = 1:2*n
        if(mod(i,2) ~= 0)
            out(i) = b1((i+1)/2);
        else
            out(i) = b2(i/2);
        end
    end
end








