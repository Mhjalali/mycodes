import java.io.FileReader;
import java.util.Scanner;

public class Thr2 extends Thread {
    @Override
    public synchronized void run() {
        FileReader fileReader = null;
        try {
            fileReader = new FileReader("A2.txt");
            Scanner scanner = new Scanner(fileReader);
            int ch;
            while (scanner.hasNextLine()) {
                ch = Integer.parseInt(scanner.nextLine());
                Tamrin4_1.ints[1] = ch;
                try {
                    wait();
                } catch (Exception e) {
                }
            }
            if (!scanner.hasNextLine()){
                Tamrin4_1.ints[1] = 2147483647;
            }
            fileReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
