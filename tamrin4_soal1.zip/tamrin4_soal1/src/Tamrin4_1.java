import java.io.FileWriter;

import static java.lang.Thread.State.TERMINATED;
import static java.lang.Thread.State.WAITING;

public class Tamrin4_1 {
    static int[] ints = new int[3];

    public static void main(String[] args) throws Exception {
        Thread t1 = new Thr1();
        Thread t2 = new Thr2();
        Thread t3 = new Thr3();
        FileWriter fileWriter1 = new FileWriter("B1.txt");
        FileWriter fileWriter2 = new FileWriter("B2.txt");
        t1.start();
        t2.start();
        t3.start();
        Thread.sleep(200);
        while (!(t1.getState() == TERMINATED && t2.getState() == TERMINATED && t3.getState() == TERMINATED)) {
            System.out.println(ints[0] + "avali");
            System.out.println(ints[1] + "dovomi");
            System.out.println(ints[2] + "sevomi");
            if (!(t1.getState() == WAITING && t2.getState() == WAITING && t3.getState() == WAITING))
                Thread.sleep(200);
            if (ints[0] <= ints[1] && ints[0] <= ints[2] && t1.getState() != TERMINATED) {
                if (ints[0] % 2 == 0) {
                    fileWriter1.write(ints[0] + "\n");
                } else if (ints[0] % 2 == 1) {
                    fileWriter2.write(ints[0] + "\n");
                }
                try {
                    synchronized (t1) {
                        t1.notify();
                    }
                } catch (Exception e) {
                }
                continue;
            }
            if (ints[1] <= ints[0] && ints[1] <= ints[2] && t2.getState() != TERMINATED) {
                if (ints[1] % 2 == 0) {
                    fileWriter1.write(ints[1] + "\n");
                } else if (ints[1] % 2 == 1) {
                    fileWriter2.write(ints[1] + "\n");
                }
                try {
                    synchronized (t2) {
                        t2.notify();
                    }
                } catch (Exception e) {
                }
                continue;
            }
            if (ints[2] <= ints[0] && ints[2] <= ints[1] && t3.getState() != TERMINATED) {
                if (ints[2] % 2 == 0) {
                    fileWriter1.write(ints[2] + "\n");
                } else if (ints[2] % 2 == 1) {
                    fileWriter2.write(ints[2] + "\n");
                }
                try {
                    synchronized (t3) {
                        t3.notify();
                    }
                } catch (Exception e) {
                }
            }
        }
        fileWriter1.close();
        fileWriter2.close();
        for (int c : ints) {
            System.out.println(c);
        }
        System.out.println(t1.getState().toString() + t2.getState().toString() + t3.getState().toString());
    }
}
