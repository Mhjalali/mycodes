import java.io.FileReader;
import java.util.Scanner;

public class Thr3 extends Thread {
    @Override
    public synchronized void run() {
        FileReader fileReader = null;
        try {
            fileReader = new FileReader("A3.txt");
            Scanner scanner = new Scanner(fileReader);
            int ch;
            while (scanner.hasNextLine()) {
                ch = Integer.parseInt(scanner.nextLine());
                Tamrin4_1.ints[2] = ch;
                try {
                    wait();
                } catch (Exception e) {
                }
            }
            if (!scanner.hasNextLine()){
                Tamrin4_1.ints[2] = 2147483647;
            }
            fileReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
