clear all
close all
%% q1 part1
wn = wgn(10001,1,0); 
t = -1 : 0.0002 : 1;
figure(1);
plot(t, wn)
%% q1 part2
ar = autocorr(wn,5000);
figure(2);
plot(ar);
Err = 1 / sqrt(length(ar));
disp(Err);
%% q1 part3 1
y = autocorr2(wn);
t = - 5000 : + 5000;
figure(3);
plot(t,y);
%% q1 part3 2.
wn2 = wgn(50001,1,0);
y2 = autocorr3(wn2);
t = - 25000 : + 25000;
figure(4);
plot(t,y2); 
%% q1 part4 1
artotal = y;
for i = 1:1000
    noise = wgn(10001,1,0);
    artotal = artotal + autocorr2(noise);
end
ar_average = artotal / 1001;
Len = length(ar_average);
h = fft(ar_average);
H = abs(h);
freq = 10000*((-Len/2+1):(Len/2))/Len;
figure(7);
plot(freq,H);

%% q1 part4 2
sn = periodogram(wn);
for i = 1:1000
    noise = wgn(10001,1,0);
    sn = sn + periodogram(noise);
end
sn_average = sn / 1001; 
l = length(sn_average);
t = -(l-1)/2 : (l-1)/2;
plot(t,10.^(sn_average/10));

%% functions
function y = autocorr2(x)
    y = zeros(10001,1);
    for t=0:5000
        for taw=0:10000-t
            y(5001+t) = y(5001+t) + x(taw+t+1)*x(taw+1);
        end
        y(5001+t) = y(5001+t)/(10001);
        y(5001-t) = y(5001+t);
    end
end

function y = autocorr3(x)
    y = zeros(50001,1);
    for t=0:25000
        for taw=0:50000-t
            y(25001+t) = y(25001+t) + x(taw+t+1)*x(taw+1);
        end
        y(25001+t) = y(25001+t)/(50001);
        y(25001-t) = y(25001+t);
    end
end