clear all
close all
%% q2 part1
[b,a] = butter(2,1000/5000);
freqz(b,a);
%% q2 part2
wn = wgn(10001 ,1 ,0);
cn = filter(b,a,wn);
t = -5 :0.001: 5;
figure(1);
plot(t,wn);
figure(2);
plot(t,cn);
%% q2 part3
car = autocorr2(cn);
t = -5000:5000;
plot(t,car);
%% q2 part4 1
cartotal = car;
for i = 1:1000
    noise = wgn(10001,1,0);
    co_noise = filter(b,a,noise);
    cartotal = cartotal + autocorr2(co_noise);
end
car_average = cartotal / 1001;
len = length(car_average);
h = fft(car_average);
H = abs(h);
freq = 10000*((-len/2+1):(len/2))/len;
figure(3);
plot(freq,H);
%% q2 part4 2
artotal = autocorr2(wn);
for i = 1:1000
    noise = wgn(10001,1,0);
    artotal = artotal + autocorr2(noise);
end
ar_average = artotal / 1001;
h = fft(ar_average);
H = abs(h);
Scn = H * (10.^(b/10)).^2;
t = -5000:5000;
figure(4)
plot(t,Scn);
%% functions
function y = autocorr2(x)
    y = zeros(10001,1);
    for t=0:5000
        for taw=0:10000-t
            y(5001+t) = y(5001+t) + x(taw+t+1)*x(taw+1);
        end
        y(5001+t) = y(5001+t)/(10001);
        y(5001-t) = y(5001+t);
    end
end