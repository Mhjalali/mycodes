clear all
close all
%% q3 part1,2
t = 0:0.01:100;
u = heaviside(t-10);
x = (t-10).^4 .* exp(10-t) .* sin(10*t-100) .* u;
figure(3)
plot(t, x);
%% q3 part3
y = x;
for i = 1:50
    tp = t - 10*(i+1);
    y = y + 0.25^i * tp.^4 .* exp(-1*tp) .* sin(10*tp) .* heaviside(tp);
end
figure(1)
plot(t, y);
%% q3 part4
l = length(y);
disp(l);
z = zeros(1,10001);
for i= 1001:l
    z(i) = y(i) - 0.25 * y(i-1000) ;
end
for i= 1:1000
    z(i) = y(i);
end
figure(2)
plot(t, z)
%% q3 part5
y2 = zeros(1,10001);
for i= 1001:l
    y2(i) = x(i) + 0.25 * x(i-1000);
end
for i= 1:1000
    y2(i) = x(i);
end
figure(4)
plot(t, y2);
xp = y2;
for i= 1001:l
    xp(i) = xp(i) - 0.25 * y2(i-1000) ;
end
for i= 2001:l
    xp(i) = xp(i) + 0.25^2 * y2(i-2000) ;
end
for i= 3001:l
    xp(i) = xp(i) - 0.25^3 * y2(i-3000) ;
end
for i= 4001:l
    xp(i) = xp(i) + 0.25^4 * y2(i-4000) ;
end
figure(5)
plot(t, xp);