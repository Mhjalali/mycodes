clc;

%% a ��� ) plotting v vector
v = [-1;1;-1;-1;1;1];
figure(1);
plot(v);
title('v Vector');

%% b � ) plotting f'(n) = f(n+1)-f(n)
v_size = size(v);
v_prim1 = zeros(v_size);
for i = 1:v_size(1)-1
    v_prim1(i) = v(i+1)-v(i);
end
v_prim1(v_size(1)) = v(v_size(1));
figure(2);
plot(v_prim1);
title("f(n)' = f(n+1)-f(n)");

%% b � ) plotting f'(n) = f(n)-f(n-1)
v_prim = vector_derivative(v);
figure(3);
plot(v_prim);
title('derivative of v Vector by W*v');

%% c � ) binary plottin
v_binary = logical(v+abs(v));
V_prim_binary = logical(v_prim+abs(v_prim));

figure(4);
subplot(2,1,1);
imagesc(v_binary');
colormap(gray);
subplot(2,1,2);
imagesc(V_prim_binary');

%% d � ) image read and plot binary image
A = imread('zebra.jpg');
figure(5);
imshow(A);
title('normal image');
A_binary = myimagebinary(A);
figure(6);
imshow(A_binary);
title('binary image');

%% e � ) derivative on image rows
A_size = size(A_binary);
A_binary_derivative1 = zeros(A_size);
for i = 1:A_size(1);
    temp = A_binary(i,:);
    temp = vector_derivative(temp');
    A_binary_derivative1(i,:) = temp';
end
figure(7);
imshow(abs(A_binary_derivative1));
title('derivative of image on rows');

%% f � ) derivative on image columns
A_size = size(A_binary);
A_binary_derivative2 = zeros(A_size);
for i = 1:A_size(2);
    temp = A_binary(:,i);
    temp = vector_derivative(temp);
    A_binary_derivative2(:,i) = temp';
end
figure(8);
imshow(abs(A_binary_derivative2));
title('derivative of image on columns');

%% g ? ) derivative on both directions
A_binary_derivative3 = A_binary_derivative1.^2 + A_binary_derivative2.^2;
A_binary_derivative3 = A_binary_derivative3 > 0;
figure(9);
imshow(A_binary_derivative3);
title('derivative of image on both rows & columns');


%% function for generating derivative of a vector
function Y = vector_derivative(y)
    y_size = size(y);
    % creating W matrix
    W = zeros(y_size(1), y_size(1));
    for i = 1:y_size(1)-1
        W(i,i) = 1;
        W(i+1,i) = -1;
    end
    W(y_size(1),y_size(1)) = 1;
    W(1,y_size(1)) = -1;
    Y = W*y;
end
