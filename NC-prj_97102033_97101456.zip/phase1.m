clear all;
close all;
vp = @(y) 36*(y(2)^4)*(-72-y(1)) + 120*(y(3)^3)*y(4)*(55-y(1)) + 0.3*(-49.4-y(1)) + 20 ;

an = @(v) 0.01*(10+(-60-v)) ./ (exp(1 + (-60-v)/10)-1);
bn = @(v) 0.125*exp((-60-v)/80);
np = @(y) an(y(1))*(1-y(2)) - y(2)*bn(y(1));

am = @(v) (0.1*(25+(-60-v)) ./ (exp(2.5 + (-60-v)/10)-1));
bm = @(v) (4*exp((-60-v)/18));
mp = @(y) am(y(1))*(1-y(3)) - y(3)*bm(y(1));

ah = @(v) 0.07*exp((-60-v)/20);
bh = @(v) 1./exp(3+((-60-v)/10)+1);
hp = @(y) ah(y(1))*(1-y(4)) - y(4)*bh(y(1));

%% plot h,n,m - v
% h' = 0 , m' = 0, n' = 0
v = linspace(-80,10);
n = @(v) an(v) ./ (an(v) + bn(v));
m = @(v) am(v) ./ (am(v) + bm(v));
h = @(v) ah(v) ./ (ah(v) + bh(v));
figure(1)
plot(v,n(v));
hold on;
plot(v,m(v));
hold on;
plot(v,h(v));
legend ('n', 'm', 'h');

%% plot v-t and v-n
t0 = [-65 0 0 0];
f = {vp,np,mp,hp};
e = euler(f,t0,0.05,100);
r = rungekutta(f,t0,0.05,100);
t = 0.05:0.05:100;
figure(2)
plot(t,e{1});
figure(3)
plot(t,r{1});
% v-n euler
v_array = e{1}(1,1501:2000);
n_array = e{2}(1,1501:2000);
figure(4)
plot(n_array,v_array);
% v-n runge kutta
v_array = r{1}(1,1501:2000);
n_array = r{2}(1,1501:2000);
figure(5)
plot(n_array,v_array);


%% functions
function f_t = euler(g,g0,h,t)
    m = length(g);
    k = t / h; 
    hold = g0;
    temp = {};
    f_t = {};
    for i = 1:k
        hold2 = zeros(1,m);
        for j = 1:m
            hold2(j) = hold(j) + h * g{j}(hold);
        end
        temp{i} = hold2;
        hold = hold2;
    end
    for i = 1:m
        hold3 = zeros(1,k);
        for j = 1:k
            hold3(j) = temp{j}(i); 
        end
        f_t{i} = hold3;
    end
end

function f_t = rungekutta(g,g0,h,t)
    m = length(g);
    k = t / h;
    hold = g0;
    temp = {};
    k1 = zeros(1,m);
    k2 = zeros(1,m);
    for i = 1:k
    	for j = 1:m
            k1(j) = h * g{j}(hold);
    	end
    	hold2 = hold + k1;
        for j = 1:m
            k2(j) = h * g{j}(hold2);
    	end
        hold2 = hold + 1/2 * (k1 + k2);
        temp{i} = hold2;
        hold = hold2;
    end
    for i = 1:m 
        hold3 = zeros(1,k);
        for j = 1:k
            hold3(j) = temp{j}(i); 
        end
        f_t{i} = hold3;
    end
end



