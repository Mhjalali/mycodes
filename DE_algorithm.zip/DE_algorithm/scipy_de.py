from data import get_data
import numpy as np
import pandas as pd
from scipy.stats import norm
from scipy.optimize import rosen, differential_evolution

data = get_data()
print(data)
print(data.iat[1, 1])


def create_portfolio_price(w: list):
    df = data.copy()
    df.columns = ['close', '1', '2', '3', '4']
    for i in range(len(df)):
        df.iat[i, 0] = w[0] * df.iat[i, 0] + w[1] * df.iat[i, 1] + w[2] * df.iat[i, 2] + w[3] * df.iat[i, 3] + w[4] * \
                       df.iat[i, 4]
    return df.drop(['1', '2', '3', '4'], axis=1)


def get_return(df):
    r = [0.0]
    for i in range(1, len(df)):
        r.append(df.iat[i, 0] / df.iat[i - 1, 0] - 1)
    return r


def func(w: list):
    df = create_portfolio_price(w)
    r_list = get_return(df)
    mean = np.mean(r_list)
    std_dev = np.std(r_list)
    VaR_90 = norm.ppf(1 - 0.9, mean, std_dev)
    VaR_95 = norm.ppf(1 - 0.95, mean, std_dev)
    VaR_99 = norm.ppf(1 - 0.99, mean, std_dev)
    r = (np.dot(w, data.iloc[236, :]) - np.dot(w, data.iloc[0, :])) / np.dot(w, data.iloc[0, :])
    return r + VaR_95


print(func([0.2, 0.2, 0.2, 0.2, 0.2]))
# bounds = []
# result = differential_evolution(rosen, bounds)
