# -*- coding: utf-8 -*-
from typing import Dict, Any
import pandas as pd
import requests
from datetime import datetime, date
import time


def name2id(id_data):
    ids = {}
    for line in id_data:
        if 'ح' in line[4]:
            continue
        if 'ذ' in line[3]:
            ids[line[3][1:]] = line[0]
        else:
            ids[line[3]] = line[0]
    return ids


def stocks_names(file):
    df = pd.read_csv(file)
    data = df.values
    return data[:, 0]


def getUrl(instrument, startDate, endDate):
    return s1 + instrument + '-1/' + timeFrame + s2 + str(startDate) + s3 + str(endDate)


def get_last_candels(instrument, n):
    return "https://api.rabin.ir/api/instrument/chart-data/" + instrument + "-1/1d?records=" + str(n)


def getInstrumentData(url):
    r = requests.get(url, proxies={"http": '', "https": ''})
    df = pd.DataFrame(r.json().get('data'))
    df.columns = columnList
    df['date'] = df['date'].str.split('T').str[0]
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)
    return df


########################################################
s0 = 'https://api.rabin.ir/api/instrument/chart-data/'
s1 = 'https://beta-api.rabin.ir/api/instrument/chart-data/'
s2 = '?startDate='
s3 = '&endDate='
########################################################

# parameters
columnList = ['open', 'high', 'low', 'close', 'volume', 'date']
timeFrame = '1d'


def get_data():
    # reading data
    id_data = pd.read_csv("raw_data/id.csv").values
    stocks = ['فولاد', 'فارس', 'شستا', 'وبصادر', 'كچاد']
    # preparing initial data
    ids = name2id(id_data)
    stock_ids = []
    for name in stocks:
        print(name)
        stock_ids.append(ids[name])

    # start & end date
    start = 1627797908000
    end = 1659333908000

    # creating new data
    dfs = []
    for id in stock_ids:
        url = getUrl(id, start, end)
        print(id)
        dfh = getInstrumentData(url)
        dfs.append(dfh["close"])

    data = pd.concat(dfs, axis=1).interpolate(method='linear').ffill().bfill()
    return data
