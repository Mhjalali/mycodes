# -*- coding: utf-8 -*-
import pytse_client as tse
import csv
import pandas as pd
import time
import datetime
import matplotlib.pyplot as plt

# stocks_list = ['اپال', 'وبملت', 'شستا', 'پارس', 'شپنا', 'وپاسار', 'زاگرس', 'کچاد', 'شپدیس', 'تاپیکو', 'شاراک', 'تاصیکو',
#                'پارسان', 'فارس', 'وغدیر', 'جم پیلن', 'مبین', 'وبصادر', 'کگهر', 'جم', 'میدکو', 'شبندر', 'فملی', 'وصندوق',
#                'شیراز', 'خساپا', 'صبا', 'بفجر', 'فولاد', 'وبانک', 'شبریز', 'بوعلی', 'شتران', 'وامید', 'آریا', 'پاکشو',
#                'وتجارت', 'شفن', 'خودرو', 'رمپنا', 'همراه', 'هرمز', 'شخارک', 'فغدیر', 'فولاژ', 'وکار', 'وخاور', 'شبهرن',
#                'شسپا']

stocks = tse.download(symbols="all", write_to_csv=True, adjust=True)
for flag in stocks.keys():
    fd = pd.read_csv("tickers_data/" + flag + '-ت' + ".csv")
    data = fd.values
    with open('tse_data/' + flag + '.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['date', 'open', 'high', 'low', 'close', 'adjclose'])
        for i in range(len(data)):
            date = time.mktime(datetime.datetime.strptime(data[i][0], '%Y-%m-%d').timetuple())
            if data[i][6] == 0:
                continue
            writer.writerow([int(date) * 1000, data[i][1], data[i][2], data[i][3], data[i][9], data[i][4]])
