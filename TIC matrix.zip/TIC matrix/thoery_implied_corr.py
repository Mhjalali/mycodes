import numpy as np
import pandas as pd
import scipy.cluster.hierarchy as sch
import scipy.spatial.distance as ssd
from scipy.cluster.hierarchy import dendrogram
import matplotlib.pyplot as plt
import seaborn as sns
import arabic_reshaper
from bidi.algorithm import get_display
from data2_daily import main


def getAtoms(lnk, item):
    # get all atoms included in an item
    anc = [item]
    while True:
        item_ = max(anc)
        if item_ <= lnk.shape[0]:
            break
        else:
            anc.remove(item_)
            anc.append(lnk['i0'][item_ - lnk.shape[0] - 1])
            anc.append(lnk['i1'][item_ - lnk.shape[0] - 1])
    return anc


def link2corr(lnk, lbls):
    # derive the correl matrix associated with a given linkage matrix
    corr = pd.DataFrame(np.eye(lnk.shape[0] + 1), index=lbls, columns=lbls,
                        dtype=float)
    for i in range(lnk.shape[0]):
        x = getAtoms(lnk, lnk['i0'][i])
        y = getAtoms(lnk, lnk['i1'][i])
        corr.loc[lbls[x], lbls[y]] = 1 - 2 * \
                                     lnk['dist'][i] ** 2  # off-diagonal values
        corr.loc[lbls[y], lbls[x]] = 1 - 2 * lnk['dist'][i] ** 2  # symmetry
    return corr


def updateDist(dist0, lnk0, lnk_, items0):
    # expand dist0 to incorporate newly created clusters
    nAtoms = len(items0) - lnk0.shape[0]
    newItems = items0[-lnk_.shape[0]:]
    for i in range(lnk_.shape[0]):
        i0, i1 = items0[int(lnk_[i, 0])], items0[int(lnk_[i, 1])]

        if lnk_[i, 0] < nAtoms:
            w0 = 1.
        else:
            w0 = lnk0[int(lnk_[i, 0]) - nAtoms, 3]
        if lnk_[i, 1] < nAtoms:
            w1 = 1.
        else:
            w1 = lnk0[int(lnk_[i, 1]) - nAtoms, 3]

        dist1 = (dist0[i0] * w0 + dist0[i1] * w1) / (w0 + w1)

        dist0[newItems[i]] = dist1  # add column
        dist0.loc[newItems[i]] = dist1  # add row
        dist0.loc[newItems[i], newItems[i]] = 0.  # main diagonal
        dist0 = dist0.drop([i0, i1], axis=0)
        dist0 = dist0.drop([i0, i1], axis=1)

    return dist0


def linkClusters(lnk0, lnk1, items0, items1):
    # transform partial link1 (based on dist1) into global link0 (based on dist0)
    nAtoms = len(items0) - lnk0.shape[0]
    lnk_ = lnk1.copy()
    for i in range(lnk_.shape[0]):
        i3 = 0
        for j in range(2):
            if lnk_[i, j] < len(items1):
                lnk_[i, j] = items0.index(items1[int(lnk_[i, j])])
            else:
                lnk_[i, j] += -len(items1) + len(items0)
            # update number of items
            if lnk_[i, j] < nAtoms:
                i3 += 1
            else:
                if lnk_[i, j] - nAtoms < lnk0.shape[0]:
                    i3 += lnk0[int(lnk_[i, j]) - nAtoms, 3]
                else:
                    i3 += lnk_[int(lnk_[i, j]) - len(items0), 3]
        lnk_[i, 3] = i3
    return lnk_


def getLinkage_corr(tree: pd.DataFrame, corr: pd.DataFrame):
    if len(np.unique(tree.iloc[:, -1])) > 1:
        tree['All'] = 0  # add top level
    lnk0 = np.empty(shape=(0, 4))
    # levels of hircical structure
    lvls = [[tree.columns[i - 1], tree.columns[i]]
            for i in range(1, tree.shape[1])]
    dist0 = ((1 - corr) / 2.) ** .5  # distance matrix
    items0 = dist0.index.tolist()  # stocks

    for cols in lvls:
        grps = tree[cols].drop_duplicates(
            cols[0]).set_index(cols[0]).groupby(cols[1])
        for cat, items1 in grps:
            items1 = items1.index.tolist()
            if len(items1) == 1:  # single item: rename
                items0[items0.index(items1[0])] = cat
                dist0 = dist0.rename({items1[0]: cat}, axis=0)
                dist0 = dist0.rename({items1[0]: cat}, axis=1)
                continue
            dist1 = dist0.loc[items1, items1]  # dist1 is the matrix of item1
            lnk1 = sch.linkage(ssd.squareform(dist1, force='tovector',
                                              checks=(not np.allclose(dist1, dist1.T))),
                               optimal_ordering=True)  # cluster that cat

            lnk_ = linkClusters(lnk0, lnk1, items0, items1)
            lnk0 = np.append(lnk0, lnk_, axis=0)
            items0 += range(len(items0), len(items0) + len(lnk_))
            dist0 = updateDist(dist0, lnk0, lnk_, items0)
            # Rename last cluster for next level
            items0[-1] = cat
            dist0.columns = dist0.columns[:-1].tolist() + [cat]
            dist0.index = dist0.columns

    dendrogram(lnk0)
    plt.show()
    lnk0 = np.fromiter(map(tuple, lnk0), dtype=[('i0', int), ('i1', int), ('dist', float), ('num', int)])
    return lnk0


main(1647021101000)
gics = pd.read_csv('cluster2.csv')
print(gics)
corr = pd.read_csv('corr.csv', index_col=0)
print(corr)
lnk0 = getLinkage_corr(gics, corr)
corr0 = link2corr(lnk0, corr.index)

stocks_list = corr0.columns
plt_stocks_list = []
for name in stocks_list:
    reshaped_text = arabic_reshaper.reshape(name)
    bidi_text = get_display(reshaped_text)
    plt_stocks_list.append(bidi_text)

corr.columns = plt_stocks_list
corr.index = plt_stocks_list
corr0.columns = plt_stocks_list
corr0.index = plt_stocks_list
sns.heatmap(corr, annot=True)
plt.show()
sns.heatmap(corr0, annot=True)
plt.show()
