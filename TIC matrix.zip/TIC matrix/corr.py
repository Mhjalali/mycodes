import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import alpaca_trade_api as tradeapi

api = tradeapi.REST('PKCTGOQYMB1500ZJ60I6',
                    'lTnR7tCdPle41jlU5kyCfnrkQCI5DA4wBLh1l986',
                    "https://paper-api.alpaca.markets")


def get_bars(symbol):
    # data = api.get_barset(symbol, 'day', limit=1000)
    data = api.get_bars(symbol, timeframe=tradeapi.rest.TimeFrame(1, tradeapi.rest.TimeFrameUnit.Day), limit=1000)
    print(data)
    data = data.df[symbol]['close']
    return data


def correlation(equity_list):
    df = pd.DataFrame()
    equity_columns = []

    # Get symbol history
    for symbol in equity_list:
        symbol_df = get_bars(symbol)
        df = pd.concat([df, symbol_df], axis=1)
        equity_columns.append(symbol)

    df.columns = equity_columns

    # Get correlation and sort by sum
    sum_corr = df.corr().sum().sort_values(ascending=True).index.values

    return df[sum_corr].corr()


pos_list = ['SNAP', 'SLV', 'JNJ', 'GOOG',
            'GLD', 'EWZ', 'CAT', 'AAPL',
            'USO', 'AAL', 'QQQ', 'AMZN',
            'MMM', 'JNK', 'TLT', 'GS']

# Call the df with the list from summed correlation, sorted ascending.
correlation(pos_list)
