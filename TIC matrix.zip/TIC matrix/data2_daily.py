# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import csv
import arabic_reshaper, math
from bidi.algorithm import get_display

# stocks_list = ['کگهر', 'کچاد', 'تاصیکو', 'وبملت', 'وبصادر', 'وتجارت', 'میدکو', 'فملی',
#                'فولاد', 'شستا', 'وصندوق', 'وغدیر', 'شپنا', 'شتران',
#                'شبندر']

# stocks_list = ['فارس', 'جم', 'پارسان', 'وبملت', 'وبصادر', 'وتجارت', 'میدکو', 'فملی',
#                'فولاد', 'وبانک', 'وصندوق', 'وغدیر', 'شپنا', 'شتران',
#                'شبندر']

# stocks_list = ['اپال',
# 'تاصیکو', 'کچاد', 'کگهر', 'شپنا', 'شبندر', 'شبهرن', 'شسپا', 'زاگرس', 'شاراک', 'بوعلی', 'پارسان',
#                'فارس', 'تاپیکو', 'وبصادر', 'وتجارت', 'وکار', 'وخاور', 'میدکو', 'فملی', 'فولاد', 'هرمز', 'فغدیر',
#                'فولاژ', 'ثشاهد', 'وساخت', 'سفارس', 'ستران', 'وغدیر', 'وبانک', 'غگل', 'وبشهر']

stocks_list = ['شپنا', 'شبندر', 'شبهرن', 'شسپا', 'زاگرس', 'شاراک',
               'فارس', 'تاپیکو', 'وبصادر', 'وتجارت', 'وکار', 'وخاور', 'فملی', 'فولاد', 'هرمز', 'فغدیر', 'خودرو',
               'خساپا', 'خمحرکه', 'خوساز', 'غبشهر', 'وبشهر', 'غسالم', 'غدشت']


def main(d):
    plt_stocks_list = []
    for name in stocks_list:
        reshaped_text = arabic_reshaper.reshape(name)
        bidi_text = get_display(reshaped_text)
        plt_stocks_list.append(bidi_text)

    columnList = ['date', 'close']
    stocks = []

    for flag in stocks_list:
        fd = pd.read_csv("tse_data/" + flag + ".csv")
        data = fd.values
        index = 0
        for i in range(len(data)):
            if int(data[i][0]) > d:
                index = i
                break
        ln = len(data)

        # for i in range(len(data) - 1):
        #     data[ln - i - 1][4] = round((data[ln - i - 1][4] - data[ln - i - 2][5]) / data[ln - i - 2][5], 5)
        for i in range(len(data) - 1):
            data[ln - i - 1][4] = math.log(data[ln - i - 1][4] / data[ln - i - 2][4])

        stocks.append(pd.DataFrame(data[index:, :]).iloc[:, [True, False, False, False, True, False]])

    print(stocks[0])

    for df in stocks:
        df.columns = columnList
        df.set_index('date', inplace=True)

    data = pd.concat(stocks, axis=1).interpolate(method='linear').ffill().bfill().corr()

    data.index = stocks_list
    data.columns = stocks_list
    data.to_csv("corr.csv")
